﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using StudentRepositorySystem.Models;

namespace StudentRepositorySystem.Controllers
{
    public class LoginController : Controller
    {
        private masterEntities db = new masterEntities();

        public ActionResult MainPage()
        {
            return View();
        }

        public ActionResult StudentRegister()
        {
            int count = db.StudentDetails.Count();
            ViewBag.studentid = count + 1000;
            return View();
        }
         
        [HttpPost]
        public ActionResult StudentRegister(StudentDetail student)
        {
            if (ModelState.IsValid)
            {
                db.StudentDetails.Add(student);
                db.SaveChanges();
                return Json(new { msg = "Successfully Registered", data = student.studentid}, JsonRequestBehavior.AllowGet);
                //return RedirectToAction("StudentLogin");
            }
            return View();
        }

        public ActionResult StudentLogin()
        {
            return View();
        }

        [HttpPost]
        public ActionResult StudentLogin(int? studentid, string password)
        {
            var isStudentIdExists = db.StudentDetails.Where(a => a.studentid == studentid).SingleOrDefault();
            if (isStudentIdExists != null)
            {
                if (isStudentIdExists.password == password)
                {
                    Session["usertype"] = "student";
                    Session["studentid"] = isStudentIdExists.studentid;
                    Session["username"] = isStudentIdExists.studentname;
                    Session["imagepath"] = "~/Images/NoImage.jpg";
                    if (isStudentIdExists.photo != null)
                    {
                        Session["imagepath"] = "~/Images/" + isStudentIdExists.photo;
                    }
                    return RedirectToAction("DashBoard", "Student");
                }
                else { ModelState.AddModelError("password", "password not matched"); }
            }
            else { ModelState.AddModelError("studentid", "Id not exists"); }
            return View();
        }

        public ActionResult AdminLogin()
        {
            return View();
        }

        [HttpPost]
        public ActionResult AdminLogin(AdminLoginDetail admin)
        {
            var isAdminIdExists = db.AdminLoginDetails.Where(a => a.adminid == admin.adminid).SingleOrDefault();
            if (isAdminIdExists != null)
            {
                if (isAdminIdExists.adminpassword == admin.adminpassword)
                {
                    Session["usertype"] = "admin";
                    Session["studentid"] = isAdminIdExists.adminid;
                    return RedirectToAction("Dashbord", "Admin");
                }
                else { ModelState.AddModelError("adminpassword", "password not matched"); }
            }
            else { ModelState.AddModelError("adminid", "Id not exists"); }
            return View(admin);
        }

        public ActionResult Logout()
        {
            Session.Clear();
            //return Content("<script>var backlen = history.length;history.go(-backlen);window.location.href='MainPage'</script>");
            //function ClearHistory()
            //{
            //    var backlen = history.length;
            //    history.go(-backlen);
            //    window.location.href = loggedOutPageUrl
            //}
            return RedirectToAction("MainPage");
        }
    }
}